import { plainToInstance } from 'class-transformer';
import { validate } from 'class-validator';
import { RequestHandler } from 'express';

/**
 * Usage:
 *   router.post('/register',
 *     validateBody(RegisterDto),
 *     controllerFn);
 */
export default function validateBody<T>(dto: new () => T): RequestHandler {
    return async (req, res, next) => {
        // transform plain JSON to class instance so decorators run
        const instance = plainToInstance(dto, req.body);

        const errors = await validate(instance, { whitelist: true });

        if (errors.length) {
            return res.status(400).json({
                message: 'Validation failed',
                errors: errors.map(e => ({
                    property: e.property,
                    constraints: e.constraints,
                })),
            });
        }

        // pass the validated & typed body downstream
        req.body = instance;
        next();
    };
}
