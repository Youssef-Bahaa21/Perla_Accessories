import { Router } from 'express';
import helmet from 'helmet';
import hpp from 'hpp';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';

const security = Router();

/* ----------  common security middleware ---------- */
security.use(helmet());
security.use(hpp());

security.use(
    rateLimit({
        windowMs: 15 * 60 * 1000, // 15 min
        max: 100,                 // 100 requests per IP
        standardHeaders: true,
        legacyHeaders: false,
    }),
);

security.use(cookieParser());
/* ----------------------------------------------- */

export default security;
