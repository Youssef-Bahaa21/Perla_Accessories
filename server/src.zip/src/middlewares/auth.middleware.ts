import { RequestHandler } from 'express';
import { AuthService } from '../services/auth.service';

const authService = new AuthService();

/**
 * Verify the JWT carried in the `token` cookie.
 *   – if valid ➜ attaches `req.user` and continues
 *   – if missing / bad ➜ responds 401
 */
export const authenticate: RequestHandler = (req, res, next) => {
    const token = req.cookies.token;               // ← cookie, not Authorization header
    if (!token) return res.sendStatus(401);

    try {
        const payload = authService.verifyToken(token);
        // expose the user payload to downstream handlers
        // eslint‑disable‑next‑line @typescript-eslint/no-explicit-any
        (req as any).user = payload;
        next();
    } catch {
        res.sendStatus(401);
    }
};
