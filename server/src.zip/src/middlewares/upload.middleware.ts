import multer from 'multer';
import path from 'path';
import fs from 'fs';

/** Ensure uploads directory exists */
const uploadDir = path.join(__dirname, '../../uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

/** Configure disk storage */
const storage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => {
        const ext = path.extname(file.originalname);
        const name = `${Date.now()}-${Math.round(Math.random() * 1e9)}${ext}`;
        cb(null, name);
    },
});

/** Only allow specific image types */
const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
const fileFilter: multer.Options['fileFilter'] = (_req, file, cb) => {
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('Invalid file type. Only JPG, PNG, WEBP allowed.'));
    }
};

/**
 * Save image files middleware factory
 * @param field the field name (e.g. "images")
 * @param maxFiles max number of files (e.g. 5)
 */
export function saveImages(field: string, maxFiles = 5) {
    return multer({
        storage,
        fileFilter,
        limits: {
            fileSize: 10 * 1024 * 1024, // 10 MB per file
        },
    }).array(field, maxFiles);
}
