// server/src/services/settings.service.ts
import { pool } from '../config/db';

export class SettingsService {
    async get(key: string): Promise<string | null> {
        const [rows]: any = await pool.query(
            `SELECT value FROM settings WHERE \`key\` = ? LIMIT 1`, [key]
        );
        return rows.length ? rows[0].value : null;
    }

    async set(key: string, value: string): Promise<void> {
        await pool.query(
            `INSERT INTO settings (\`key\`, value)
       VALUES (?, ?)
       ON DUPLICATE KEY UPDATE value = VALUES(value)`,
            [key, value]
        );
    }
}
