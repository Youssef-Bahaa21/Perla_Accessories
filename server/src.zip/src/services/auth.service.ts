import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { pool } from '../config/db';
import bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();

/* ----------  SECRET CONFIG  ---------- */
const JWT_SECRET = process.env.JWT_SECRET as string;
if (!JWT_SECRET || JWT_SECRET.length < 10) {
    throw new Error('Missing JWT_SECRET – check your .env file');
}
/* ------------------------------------- */

export interface RegisterDTO {
    email: string;
    password: string;
}
export interface LoginDTO {
    email: string;
    password: string;
}

export class AuthService {
    /** helper: sign a JWT with consistent settings */
    private sign(payload: object, expires = '1h') {
        return jwt.sign(payload, JWT_SECRET, { expiresIn: expires });
    }

    async register(dto: RegisterDTO) {
        const hashed = await bcrypt.hash(dto.password, 10);

        const [result]: any = await pool.query(
            'INSERT INTO `user` (email, password) VALUES (?, ?);',
            [dto.email, hashed],
        );

        const user = { id: result.insertId, email: dto.email, role: 'customer' };

        // link guest orders (if any)
        await pool.query(
            'UPDATE `order` SET user_id = ? WHERE user_id IS NULL AND shipping_email = ?',
            [user.id, user.email],
        );

        const token = this.sign(user);
        return { user, token };
    }

    async login(email: string, password: string) {
        const [rows]: any = await pool.query(
            'SELECT id, email, role, `password` FROM `user` WHERE email = ?',
            [email],
        );
        const user = rows[0];
        if (!user) throw new Error('User not found');

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) throw new Error('Invalid password');

        // link guest orders
        await pool.query(
            'UPDATE `order` SET user_id = ? WHERE user_id IS NULL AND shipping_email = ?',
            [user.id, user.email],
        );

        const token = this.sign(user);
        return { user, token };
    }

    verifyToken(token: string) {
        return jwt.verify(token, JWT_SECRET) as {
            id: number;
            email: string;
            role: string;
        };
    }

    generateToken(user: { id: number; email: string; role: string }) {
        return this.sign(user);
    }

    /* ----------  refresh‑token helpers ---------- */
    async generateRefreshToken(userId: number): Promise<string> {
        const token = uuidv4();
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30);

        await pool.query(
            'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?, ?, ?)',
            [userId, token, expiresAt],
        );
        return token;
    }

    async refreshAccessToken(refreshToken: string): Promise<string | null> {
        const [tokens]: any = await pool.query(
            'SELECT * FROM refresh_tokens WHERE token = ? AND expires_at > NOW() AND is_revoked = 0',
            [refreshToken],
        );
        if (!tokens.length) return null;

        const userId = tokens[0].user_id;
        const [users]: any = await pool.query(
            'SELECT id, email, role FROM user WHERE id = ?',
            [userId],
        );
        if (!users.length) return null;

        return this.sign(users[0]);
    }

    async revokeRefreshToken(token: string): Promise<void> {
        await pool.query(
            'UPDATE refresh_tokens SET is_revoked = 1 WHERE token = ?',
            [token],
        );
    }
}
