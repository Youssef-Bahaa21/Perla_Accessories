import { pool } from '../config/db';

export interface CreateProductDTO {
    name: string;
    description?: string;
    price: number;
    stock: number;
    category_id: number;
    is_new?: number;
    is_best_seller?: number;
    is_featured?: number;
}

export interface UpdateProductDTO {
    name?: string;
    description?: string;
    price?: number;
    stock?: number;
    category_id?: number;
    is_new?: number;
    is_best_seller?: number;
    is_featured?: number;
}

export interface ProductWithImages {
    id: number;
    name: string;
    description: string;
    price: number;
    stock: number;
    category_id: number;
    is_new: number;
    is_best_seller: number;
    is_featured: number;
    created_at: string;
    images: { id: number; product_id: number; image: string }[];
}

export interface PagedProducts {
    data: ProductWithImages[];
    page: number;
    limit: number;
    total: number;
}

export class ProductService {
    /* ----------  PAGED LIST  ---------- */
    /* ----------  PAGED LIST (fallback, works on any MySQL 5.x)  ---------- */
    async findPage(page = 1, limit = 20): Promise<PagedProducts> {
        page = Math.max(1, page);
        limit = Math.max(1, Math.min(100, limit));
        const offset = (page - 1) * limit;

        // 1) get the page of products
        const [products]: any[] = await pool.query(
            'SELECT SQL_CALC_FOUND_ROWS * FROM product LIMIT ? OFFSET ?',
            [limit, offset],
        );
        const [[{ total }]]: any[] = await pool.query('SELECT FOUND_ROWS() AS total');

        // 2) get all images that belong to those products
        const ids = products.map((p: any) => p.id);
        let images: any[] = [];
        if (ids.length) {
            [images] = await pool.query(
                'SELECT id, product_id, image FROM product_images WHERE product_id IN (?)',
                [ids],
            );
        }

        // 3) attach images array to each product
        const map = new Map<number, any[]>();
        images.forEach(img => {
            if (!map.has(img.product_id)) map.set(img.product_id, []);
            map.get(img.product_id)!.push(img);
        });

        const data = products.map((p: any) => ({
            ...p,
            images: map.get(p.id) || [],
        }));

        return { data, page, limit, total };
    }


    /* ----------  SINGLE PRODUCT  ---------- */
    /*  ProductService.findOne  (replace the entire method) */
    async findOne(id: number) {
        /* 1) product row */
        const [[product]]: any[] = await pool.query(
            'SELECT * FROM product WHERE id = ?',
            [id],
        );
        if (!product) return null;

        /* 2) its images */
        const [images]: any[] = await pool.query(
            'SELECT id, product_id, image FROM product_images WHERE product_id = ?',
            [id],
        );

        return { ...product, images };
    }


    /* ----------  CREATE  ---------- */
    async create(dto: CreateProductDTO) {
        const [res]: any = await pool.query(
            `
      INSERT INTO product
        (name, description, price, stock,
         category_id, is_new, is_best_seller, is_featured)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?);
      `,
            [
                dto.name,
                dto.description || null,
                dto.price,
                dto.stock,
                dto.category_id,
                dto.is_new || 0,
                dto.is_best_seller || 0,
                dto.is_featured || 0,
            ],
        );
        return { id: res.insertId, ...dto, created_at: new Date(), images: [] };
    }

    /* ----------  UPDATE  ---------- */
    async update(id: number, dto: UpdateProductDTO) {
        const allowed = [
            'name',
            'description',
            'price',
            'stock',
            'category_id',
            'is_new',
            'is_best_seller',
            'is_featured',
        ] as const;

        const fields: string[] = [];
        const params: any[] = [];

        for (const key of allowed) {
            if (dto[key] !== undefined) {
                fields.push(`${key} = ?`);
                params.push(dto[key as keyof UpdateProductDTO]);
            }
        }

        if (!fields.length) return;
        params.push(id);

        await pool.query(`UPDATE product SET ${fields.join(', ')} WHERE id = ?;`, params);
    }

    /* ----------  DELETE  ---------- */
    async remove(id: number) {
        await pool.query('DELETE FROM product WHERE id = ?;', [id]);
    }

    /* ----------  IMAGE HELPERS (unchanged)  ---------- */
    async uploadImages(productId: number, images: string[]) {
        const values = images.map(img => [productId, img]);
        const [res]: any = await pool.query(
            'INSERT INTO product_images (product_id, image) VALUES ?;',
            [values],
        );
        return {
            success: true,
            images: images.map((image, idx) => ({
                id: res.insertId + idx,
                product_id: productId,
                image,
            })),
        };
    }

    async getImages(productId: number) {
        const [rows]: any[] = await pool.query(
            'SELECT id, product_id, image FROM product_images WHERE product_id = ?;',
            [productId],
        );
        return rows;
    }

    async deleteImage(productId: number, imageId: number) {
        await pool.query(
            'DELETE FROM product_images WHERE product_id = ? AND id = ?;',
            [productId, imageId],
        );
    }
}
