import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import 'reflect-metadata';

import authRoutes from './routes/auth';
import userRoutes from './routes/users';
import productRoutes from './routes/products';
import categoryRoutes from './routes/categories';
import reviewRoutes from './routes/reviews';
import couponRoutes from './routes/coupons';
import orderRoutes from './routes/orders';
import settingsRoutes from './routes/settings';

import security from './middlewares/security';

dotenv.config();
const app = express();
const port = Number(process.env.PORT) || 3000;

/* ---- Middleware: security + CORS ---- */
app.use(cors({
    origin: 'http://localhost:4200',
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization'],
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}));

// Apply security middleware to API routes only, not static files
app.use('/api', security);

app.use(express.json());

/* ---- Serve static uploads with correct CORS headers ---- */
app.use('/uploads', (req, res, next) => {
    console.log(`Request to /uploads: ${req.url}`); // Debug log
    res.set('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.set('Access-Control-Allow-Methods', 'GET');
    res.set('Access-Control-Allow-Headers', 'Content-Type');
    res.set('Vary', 'Origin'); // Ensure proper caching of CORS headers
    console.log('Response headers set:', res.getHeaders()); // Debug log
    next();
});
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

/* ---- API Routes ---- */
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/coupons', couponRoutes);
app.use('/api/orders', orderRoutes);

/* ---- Catch Errors ---- */
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    console.error('Server error:', err);
    if (!res.headersSent) {
        res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
    }
});

/* ---- Start Server ---- */
app.listen(port, () => {
    console.log(`🚀 Server running at http://localhost:${port}`);
});