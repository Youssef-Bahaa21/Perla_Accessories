// server/src/controllers/settings.controller.ts
import { RequestHandler } from 'express';
import { SettingsService } from '../services/settings.service';

const svc = new SettingsService();

// GET /api/settings/shipping-fee
export const getShippingFee: RequestHandler = async (_req, res, next) => {
    try {
        const val = await svc.get('shipping_fee');
        const parsed = val !== null ? parseFloat(val) : 0;
        res.json({ shipping_fee: isNaN(parsed) ? 0 : parsed });
    } catch (e) {
        next(e);
    }
};

// PUT /api/settings/shipping-fee
export const updateShippingFee: RequestHandler = async (req, res, next) => {
    try {
        const fee = req.body.shipping_fee;
        if (typeof fee !== 'number' || isNaN(fee) || fee < 0) {
            return res.status(400).json({ error: 'Invalid shipping fee' });
        }

        await svc.set('shipping_fee', fee.toString());
        res.json({ shipping_fee: fee });
    } catch (e) {
        next(e);
    }
};
