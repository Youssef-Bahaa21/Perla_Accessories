import { RequestHandler } from 'express';
import { unlink } from 'fs/promises';
import upload from '../middlewares/upload.middleware';
import {
    ProductService,
    CreateProductDTO,
    UpdateProductDTO,
} from '../services/product.service';

const svc = new ProductService();
const baseUrl = 'http://localhost:3000/uploads/';

/* -------------------------------------------------
 * GET /api/products?page=1&limit=20
 *   – returns { data, page, limit, total }
 * ------------------------------------------------- */
export const getProducts: RequestHandler = async (req, res, next) => {
    try {
        const page = Math.max(1, parseInt(req.query.page as string) || 1);
        const limit = Math.max(1, Math.min(100, parseInt(req.query.limit as string) || 20));

        const result = await svc.findPage(page, limit);
        const productsWithImages = result.data.map(p => ({
            ...p,
            images: p.images.map(img => ({
                id: img.id,
                product_id: img.product_id,
                url: `${baseUrl}${img.image}`,
            })),
        }));
        res.json({ ...result, data: productsWithImages });
    } catch (err) { next(err); }
};

/* ------------------------------------------------- */
export const getProduct: RequestHandler = async (req, res, next) => {
    try {
        const p = await svc.findOne(+req.params.id);
        if (!p) return res.status(404).json({ message: 'Product not found' });
        const productWithImages = {
            ...p,
            images: p.images.map(img => ({
                id: img.id,
                product_id: img.product_id,
                url: `${baseUrl}${img.image}`,
            })),
        };
        res.json(productWithImages);
    } catch (err) { next(err); }
};

/* ------------------------------------------------- */
export const createProduct: RequestHandler = async (req, res, next) => {
    try {
        const {
            name,
            description,
            price,
            stock,
            category_id,
            is_new,
            is_best_seller,
            is_featured,
        } = req.body;

        if (!name || isNaN(price) || isNaN(stock) || isNaN(category_id)) {
            return res.status(400).json({ message: 'Missing or invalid fields' });
        }

        const dto: CreateProductDTO = {
            name,
            description,
            price: parseFloat(price),
            stock: parseInt(stock, 10),
            category_id: parseInt(category_id, 10),
            is_new: is_new ? parseInt(is_new, 10) : 0,
            is_best_seller: is_best_seller ? parseInt(is_best_seller, 10) : 0,
            is_featured: is_featured ? parseInt(is_featured, 10) : 0,
        };

        const newProd = await svc.create(dto);
        res.status(201).json(newProd);
    } catch (err) { next(err); }
};

/* ------------------------------------------------- */
export const updateProduct: RequestHandler = async (req, res, next) => {
    try {
        const dto: UpdateProductDTO = {};
        if (req.body.name !== undefined) dto.name = req.body.name;
        if (req.body.description !== undefined) dto.description = req.body.description;
        if (req.body.price !== undefined) dto.price = parseFloat(req.body.price);
        if (req.body.stock !== undefined) dto.stock = parseInt(req.body.stock, 10);
        if (req.body.category_id !== undefined) dto.category_id = parseInt(req.body.category_id, 10);
        if (req.body.is_new !== undefined) dto.is_new = parseInt(req.body.is_new, 10);
        if (req.body.is_best_seller !== undefined) dto.is_best_seller = parseInt(req.body.is_best_seller, 10);
        if (req.body.is_featured !== undefined) dto.is_featured = parseInt(req.body.is_featured, 10);

        if (!Object.keys(dto).length) {
            return res.status(400).json({ message: 'No valid fields to update' });
        }

        await svc.update(+req.params.id, dto);
        res.status(200).json({ message: 'Product updated successfully' });
    } catch (err) { next(err); }
};

/* ------------------------------------------------- */
export const deleteProduct: RequestHandler = async (req, res, next) => {
    try {
        await svc.remove(+req.params.id);
        res.status(200).json({ message: 'Product deleted successfully' });
    } catch (err) { next(err); }
};

/* ------------------------------------------------- */
export const uploadProductImages: RequestHandler = async (req, res, next) => {
    try {
        const files = req.files as Express.Multer.File[];

        if (!files?.length) {
            return res.status(400).json({ message: 'No images uploaded' });
        }

        const filenames = files.map(f => f.filename);
        const result = await svc.uploadImages(+req.params.productId, filenames);
        const imagesWithUrls = result.images.map(img => ({
            ...img,
            url: `${baseUrl}${img.image}`,
        }));
        res.status(201).json({ success: true, images: imagesWithUrls });
    } catch (err) {
        next(err);
    }
};

/* ------------------------------------------------- */
export const getProductImages: RequestHandler = async (req, res, next) => {
    try {
        const images = await svc.getImages(+req.params.productId);
        const imagesWithUrls = images.map(img => ({
            id: img.id,
            product_id: img.product_id,
            url: `${baseUrl}${img.image}`,
        }));
        res.json(imagesWithUrls);
    } catch (err) { next(err); }
};

/* ------------------------------------------------- */
export const deleteProductImage: RequestHandler = async (req, res, next) => {
    try {
        const imgs = await svc.getImages(+req.params.productId);
        const img = imgs.find(i => i.id === +req.params.imageId);
        if (!img) return res.status(404).json({ message: 'Image not found' });

        await svc.deleteImage(+req.params.productId, +req.params.imageId);
        await unlink(`uploads/${img.image}`).catch(() => { });
        res.status(200).json({ message: 'Image deleted successfully' });
    } catch (err) { next(err); }
};