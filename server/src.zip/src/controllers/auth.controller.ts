import { RequestHandler } from 'express';
import { AuthService } from '../services/auth.service';
import { RegisterDto } from '../dtos/register.dto';
import validateBody from '../middlewares/validate';

const svc = new AuthService();

/* ----------  shared cookie options ---------- */
const cookieOpts = {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 60 * 60 * 1000,           // 1 hour
};
/* ------------------------------------------- */

/* -------------------------------------------------
 * POST /api/auth/register
 *   – validates body
 *   – creates user
 *   – sets JWT cookie
 *   – returns user (no token in JSON)
 * ------------------------------------------------- */
const registerHandler: RequestHandler = async (req, res, next) => {
    try {
        const dto = req.body as RegisterDto;

        const { user, token } = await svc.register(dto);

        res
            .cookie('token', token, cookieOpts)
            .status(201)
            .json({ message: 'Registration successful', user });
    } catch (e) {
        next(e);
    }
};

export const register = [validateBody(RegisterDto), registerHandler];

/* -------------------------------------------------
 * POST /api/auth/login
 *   – validates body using same DTO (email & password)
 *   – logs user in
 *   – sets JWT cookie
 *   – returns user
 * ------------------------------------------------- */
const loginHandler: RequestHandler = async (req, res, next) => {
    try {
        const dto = req.body as RegisterDto;        // same fields
        const { user, token } = await svc.login(dto.email, dto.password);

        res
            .cookie('token', token, cookieOpts)
            .json({ message: 'Login successful', user });
    } catch (e) {
        next(e);
    }
};

export const login = [validateBody(RegisterDto), loginHandler];
