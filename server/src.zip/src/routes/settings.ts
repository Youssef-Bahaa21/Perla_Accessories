// server/src/routes/settings.ts
import { Router } from 'express';
import { getShippingFee, updateShippingFee } from '../controllers/settings.controller';

const router = Router();

router.get('/shipping-fee', getShippingFee);
router.put('/shipping-fee', updateShippingFee);

export default router;
