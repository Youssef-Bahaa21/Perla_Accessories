import { Router } from 'express';
import {
    getProducts,
    getProduct,
    createProduct,
    updateProduct,
    deleteProduct,
    uploadProductImages,   // controller adds images to DB
    getProductImages,
    deleteProductImage,
} from '../controllers/product.controller';

import { saveImages } from '../middlewares/upload.middleware'; // sharp + limits

const router = Router();

/* ---------- catalogue + CRUD ---------- */
router.get('/', getProducts);
router.get('/:id', getProduct);
router.post('/', createProduct);
router.put('/:id', updateProduct);
router.delete('/:id', deleteProduct);

/* ---------- image endpoints ---------- */
router.post(
    '/:productId/images',
    saveImages('images', 5),      // ← replaces old upload.array(...)
    uploadProductImages,
);

router.get('/:productId/images', getProductImages);
router.delete('/:productId/images/:imageId', deleteProductImage);

export default router;
