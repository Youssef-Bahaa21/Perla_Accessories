// server/src/routes/auth.routes.ts

import { Router } from 'express';
import { register, login } from '../controllers/auth.controller';
import { authenticate } from '../middlewares/auth.middleware';

const router = Router();

// POST /api/auth/register
router.post('/register', register);

// POST /api/auth/login
router.post('/login', login);

router.post('/logout', (req, res) => {
    res.clearCookie('token', { httpOnly: true, sameSite: 'lax' });
    res.sendStatus(204);
});

router.get('/me', authenticate, (req, res) => {
    // @ts-ignore – added by auth.middleware
    res.json(req.user);
});

export default router;