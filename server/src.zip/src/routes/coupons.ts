import { Router } from 'express';
import { getCouponUsage } from '../controllers/coupon-usage.controller';

import {
    listCoupons,
    getCoupon,
    createCoupon,
    updateCoupon,
    deleteCoupon,
    validateCoupon
} from '../controllers/coupon.controller';

const router = Router();

router.get('/', listCoupons);

router.get('/:id', getCoupon);
router.post('/', createCoupon);
router.put('/:id', updateCoupon);
router.get('/:id/usage', getCouponUsage); // 👈 add this

router.delete('/:id', deleteCoupon);
router.post('/validate', validateCoupon);

export default router;