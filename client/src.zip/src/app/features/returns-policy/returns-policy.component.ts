import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-returns-policy',
    standalone: true,
    imports: [CommonModule, RouterModule],
    template: `
    <div class="min-h-screen bg-gradient-to-b from-white via-pink-50/30 to-pink-100/20 py-16">
      <div class="max-w-3xl mx-auto px-4 sm:px-6">
        <!-- Page Title -->
        <div class="text-center mb-12">
          <h1 class="text-3xl sm:text-4xl font-bold text-gray-900 mb-4 relative inline-block">
            Returns & Exchanges Policy
            <span class="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full"></span>
          </h1>
        </div>

        <!-- Content -->
        <div class="bg-white rounded-2xl shadow-md p-8 mb-12">
          <div class="prose prose-pink max-w-none">
            <p class="mb-6 text-gray-600">At Perla Accessories, we want you to be completely satisfied with your purchase. Please read our returns and exchanges policy carefully.</p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-8 mb-4">Returns Policy</h2>
            <p class="text-gray-600">We do not offer returns or exchanges except in the case of receiving an incorrect item. If you receive the wrong item, please contact us on the same day you received it and inform us that the item is incorrect. In this case, we will take full responsibility to replace it.</p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-8 mb-4">Unsatisfactory Items</h2>
            <p class="text-gray-600">If you receive an order and you are not satisfied with the item in any way, please contact us on the same day you received it. In this case, the full shipping cost will be your responsibility. Please note that some items may not be eligible for return based on their condition or nature.</p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-8 mb-4">Return Process</h2>
            <p class="text-gray-600">To initiate a return, please contact our customer service team on the same day of receiving your order. We will provide you with instructions on how to proceed with the return. Returns initiated after the same-day notification period may not be accepted.</p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-8 mb-4">Contact Us</h2>
            <p class="text-gray-600">If you have any questions about our returns and exchanges policy, please contact us at contact&#64;perla.com.</p>
          </div>
        </div>
        
        <!-- Back Button -->
        <div class="text-center">
          <a routerLink="/" class="inline-flex items-center text-pink-600 hover:text-pink-700 font-medium">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Home
          </a>
        </div>
      </div>
    </div>
  `,
})
export class ReturnsPolicyComponent { }