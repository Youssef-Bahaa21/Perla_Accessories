import {
  Component,
  OnInit,
  HostListener,
  inject,
  PLATFORM_ID,
  Inject,
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterModule, RouterLink } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ApiService } from '../../../core/services/api/api.service';
import { ProductService } from '../../../core/services/product.service';
import { CartService } from '../../../core/services/cart/cart.service';
import { Product, Category } from '../../../core/models';

@Component({
  selector: 'app-product-list',
  standalone: true,
  templateUrl: './product-list.component.html',
  imports: [
    CommonModule,
    RouterModule,
    RouterLink,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  categories: Category[] = [];
  activeImageIndices: { [pid: number]: number } = {};
  addedToCartMessage: { [pid: number]: string } = {};
  loading = true;
  error = '';
  fallbackImage = 'https://via.placeholder.com/150'; // Fallback image if loading fails

  page = 1;
  pageSize = 12;
  allProductsLoaded = false;

  selectedCategory: number | 'all' = 'all';
  stockFilter: 'all' | 'in' | 'out' = 'all';
  tagFilter: 'all' | 'new' | 'best' = 'all';

  showMobileFilters = false;
  touchStartX = 0;
  isBrowser: boolean;
  selectedProduct?: Product;

  private api = inject(ApiService);
  private productSvc = inject(ProductService);
  private cart = inject(CartService);

  constructor(@Inject(PLATFORM_ID) platformId: object) {
    this.isBrowser = isPlatformBrowser(platformId);
  }

  ngOnInit() {
    this.loadPage();

    this.api.categories.list().subscribe({
      next: cats => (this.categories = cats),
      error: () => (this.error = 'Could not load categories.'),
    });
  }

  private loadPage() {
    this.loading = true;

    this.productSvc.getProducts<Product>(this.page, this.pageSize).subscribe({
      next: resp => {
        const newItems = resp.data.map(p => {
          const images = (p.images || []).map(img => {
            return {
              id: img.id,
              url: img.url,
            };
          });
          return {
            ...p,
            images: images,
          };
        });
        this.products.push(...newItems);

        newItems.forEach(p => {
          this.activeImageIndices[p.id] = 0;
        });

        this.applyFilters();
        this.loading = false;

        const totalPages = Math.ceil(resp.total / this.pageSize);
        this.allProductsLoaded = this.page >= totalPages;
      },
      error: () => {
        this.error = 'Could not load products.';
        this.loading = false;
      },
    });
  }

  @HostListener('window:scroll', [])
  onScroll(): void {
    const threshold = document.documentElement.scrollHeight - 300;
    const position = window.pageYOffset + window.innerHeight;

    if (position > threshold && !this.loading && !this.allProductsLoaded) {
      this.page++;
      this.loadPage();
    }
  }

  applyFilters() {
    this.filteredProducts = this.products.filter(p => {
      const byCat = this.selectedCategory === 'all' || p.category_id === +this.selectedCategory;
      const byStock =
        this.stockFilter === 'all' ||
        (this.stockFilter === 'in' && p.stock > 0) ||
        (this.stockFilter === 'out' && p.stock === 0);
      const byTag =
        this.tagFilter === 'all' ||
        (this.tagFilter === 'new' && p.is_new) ||
        (this.tagFilter === 'best' && p.is_best_seller);

      return byCat && byStock && byTag;
    });
  }

  clearFilters() {
    this.selectedCategory = 'all';
    this.stockFilter = 'all';
    this.tagFilter = 'all';
    this.applyFilters();
  }

  addToCart(p: Product) {
    this.cart.add(p);
    this.addedToCartMessage[p.id] = 'Added to cart!';
    setTimeout(() => (this.addedToCartMessage[p.id] = ''), 2000);
  }

  openQuickView(p: Product) { this.selectedProduct = p; document.body.style.overflow = 'hidden'; }
  closeQuickView() { this.selectedProduct = undefined; document.body.style.overflow = ''; }

  setActiveImage(pid: number, idx: number) { this.activeImageIndices[pid] = idx; }
  showNextImage(pid: number, count: number) {
    if (count > 1) this.activeImageIndices[pid] = 1;
  }
  resetImage(pid: number) { this.activeImageIndices[pid] = 0; }

  handleTouchStart(event: TouchEvent, _productId: number): void {
    this.touchStartX = event.touches[0].clientX;
  }
  handleTouchMove(e: TouchEvent, pid: number, count: number) {
    if (count <= 1) return;
    const diff = this.touchStartX - e.touches[0].clientX;
    if (Math.abs(diff) > 30) {
      const cur = this.activeImageIndices[pid];
      this.setActiveImage(
        pid,
        diff > 0 ? (cur < count - 1 ? cur + 1 : 0) : (cur > 0 ? cur - 1 : count - 1),
      );
      this.touchStartX = e.touches[0].clientX;
    }
  }

  hasActiveFilters() {
    return this.stockFilter !== 'all' || this.selectedCategory !== 'all' || this.tagFilter !== 'all';
  }
  getCategoryName(id: number | 'all'): string {
    if (id === 'all') return '';
    return this.categories.find(c => c.id === +id)?.name || 'Unknown';
  }

  getWindowWidth(): number {
    return this.isBrowser ? window.innerWidth : 1024;
  }

  toggleMobileFilters(): void {
    this.showMobileFilters = !this.showMobileFilters;
  }

  resetStockFilter() {
    this.stockFilter = 'all';
    this.applyFilters();
  }
  resetCategoryFilter() {
    this.selectedCategory = 'all';
    this.applyFilters();
  }
  resetTagFilter() {
    this.tagFilter = 'all';
    this.applyFilters();
  }

  onImageError(event: Event) {
    (event.target as HTMLImageElement).src = this.fallbackImage;
  }
}