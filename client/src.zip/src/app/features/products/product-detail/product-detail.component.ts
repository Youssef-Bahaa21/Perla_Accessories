import { Component, OnInit, inject, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '../../../core/services/api/api.service';
import { Product, Review } from '../../../core/models';
import { CartService } from '../../../core/services/cart/cart.service';
import { ReviewFormComponent } from '../review-form/review-form/review-form.component';
import { CarouselModule } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReviewFormComponent,
    CarouselModule
  ],
  styleUrls: ['./product-detail.component.css'],
  templateUrl: './product-detail.component.html',
})
export class ProductDetailComponent implements OnInit {
  product?: Product;
  reviews: Review[] = [];
  loading = true;
  error = '';
  cartMessage = '';
  fallbackImage = 'https://via.placeholder.com/150';

  carouselOptions = {
    loop: true,
    margin: 10,
    nav: true,
    navText: ['<span class="carousel-nav-btn hidden sm:flex">❮</span>', '<span class="carousel-nav-btn hidden sm:flex">❯</span>'],
    dots: true,
    autoplay: true,
    autoplayTimeout: 3000,
    responsive: {
      0: { items: 1 },
      768: { items: 1 }
    }
  };

  private api = inject(ApiService);
  private cart = inject(CartService);
  private route = inject(ActivatedRoute);

  constructor(@Inject(PLATFORM_ID) private platformId: Object) { }

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (!id) {
      this.error = 'Invalid product ID.';
      this.loading = false;
      return;
    }

    this.api.products.get(id).subscribe({
      next: p => {
        this.product = {
          ...p,
          images: (p.images || []).map(img => ({
            id: img.id,
            url: img.url,
          })),
        };
        this.loading = false;
      },
      error: () => {
        this.error = 'Could not load product.';
        this.loading = false;
      }
    });

    this.loadReviews(id);
  }

  private loadReviews(id: number) {
    this.api.reviews.list().subscribe({
      next: all => {
        this.reviews = all.filter(r => r.product_id === id);
      },
      error: () => { }
    });
  }

  addToCart() {
    if (this.product) {
      this.cart.add(this.product);
      this.cartMessage = '✅ Added to cart!';
      setTimeout(() => (this.cartMessage = ''), 3000);
    }
  }

  isLoggedIn(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      return !!localStorage.getItem('token');
    }
    return false;
  }

  isAdmin(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      try {
        const token = localStorage.getItem('token');
        const payload = token ? JSON.parse(atob(token.split('.')[1])) : null;
        return payload?.role === 'admin';
      } catch {
        return false;
      }
    }
    return false;
  }

  deleteReview(id: number) {
    if (!confirm('Are you sure?')) return;
    this.api.reviews.delete(id).subscribe({
      next: () => this.product && this.loadReviews(this.product.id),
      error: () => alert('Failed to delete review.')
    });
  }

  getStockPhrase(stock: number): string {
    if (stock === 0) return 'Out of stock';
    if (stock > 0 && stock <= 5) return 'Only a few left!';
    return 'In stock';
  }

  onReviewSubmitted() {
    if (this.product) {
      this.loadReviews(this.product.id);
    }
  }

  onImageError(event: Event) {
    (event.target as HTMLImageElement).src = this.fallbackImage;
  }
}