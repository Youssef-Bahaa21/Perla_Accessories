// src/app/features/cart/cart.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CartItem, CartService } from '../../core/services/cart/cart.service';
import { ApiService } from '../../core/services/api/api.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './cart.component.html',
})
export class CartComponent implements OnInit {
  cart$: Observable<CartItem[]>;
  cartItems: CartItem[] = [];
  total = 0;
  deliveryFee = 0;

  constructor(
    private cartService: CartService,
    private api: ApiService,
    private router: Router
  ) {
    this.cart$ = this.cartService.cart$;
  }

  ngOnInit(): void {
    this.cart$.subscribe(items => {
      this.cartItems = items;
      this.total = items.reduce((sum, i) => sum + i.product.price * i.qty, 0);
    });

    this.api.settings.getShippingFee().subscribe({
      next: (res) => this.deliveryFee = res.shipping_fee,
      error: () => this.deliveryFee = 0
    });
  }

  get subTotal(): number {
    return this.cartItems.reduce((sum, i) => sum + i.product.price * i.qty, 0);
  }

  get grandTotal(): number {
    return this.cartItems.length > 0 ? this.total + this.deliveryFee : 0;
  }

  remove(item: CartItem): void {
    this.cartService.remove(item.product.id);
  }

  updateQty(item: CartItem, change: number): void {
    const newQty = item.qty + change;
    if (newQty <= 0) {
      this.remove(item);
    } else {
      this.cartService.updateQuantity(item.product.id, newQty);
    }
  }

  clearCart(): void {
    this.cartService.clear();
  }

  checkout(): void {
    this.router.navigateByUrl('/shipping');
  }

  shouldShowDeliveryFee(): boolean {
    return this.cartItems.length > 0;
  }
}