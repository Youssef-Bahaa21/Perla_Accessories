// src/app/features/shiiping-details/shiiping-details.component.ts
import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router } from '@angular/router';
import { ShippingInfo } from '../../core/models';
import { inject } from '@angular/core';
import { AuthService } from '../../core/services/auth/auth.service';

// Create a service to store shipping details between checkout steps
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CheckoutService {
  private shippingInfoSubject = new BehaviorSubject<ShippingInfo | null>(null);
  shippingInfo$ = this.shippingInfoSubject.asObservable();

  saveShippingInfo(info: ShippingInfo): void {
    this.shippingInfoSubject.next(info);
  }

  getShippingInfo(): ShippingInfo | null {
    return this.shippingInfoSubject.value;
  }

  clearShippingInfo(): void {
    this.shippingInfoSubject.next(null);
  }
}

@Component({
  selector: 'app-shipping-details',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './shiiping-details.component.html',
})
export class ShippingDetailsComponent implements OnInit {
  form!: FormGroup;
  @Output() submitted = new EventEmitter<ShippingInfo>();

  private router = inject(Router);
  private checkoutService = inject(CheckoutService);
  private authService = inject(AuthService);

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    // Pre-fill form if we have stored shipping info
    const savedInfo = this.checkoutService.getShippingInfo();

    // Initialize form
    this.form = this.fb.group({
      name: [savedInfo?.name || '', Validators.required],
      email: [savedInfo?.email || '', [Validators.required, Validators.email]],
      address: [savedInfo?.address || '', Validators.required],
      city: [savedInfo?.city || '', Validators.required],
      phone: [savedInfo?.phone || '', Validators.required]
    });

    // Try to pre-fill email from logged in user
    if (!savedInfo?.email) {
      const currentUser = this.authService.currentUser$.value;
      if (currentUser?.email) {
        this.form.get('email')?.setValue(currentUser.email);
      }
    }
  }

  onSubmit() {
    if (this.form.valid) {
      const shippingInfo = this.form.value as ShippingInfo;

      // Store shipping info in the service for the next step
      this.checkoutService.saveShippingInfo(shippingInfo);

      // Emit the shipping info (for compatibility with existing code)
      this.submitted.emit(shippingInfo);

      // Navigate to the checkout page
      this.router.navigateByUrl('/checkout');
    } else {
      // Mark all form controls as touched to show validation errors
      Object.keys(this.form.controls).forEach(key => {
        const control = this.form.get(key);
        control?.markAsTouched();
      });
    }
  }
}
