import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-about',
    standalone: true,
    imports: [CommonModule, RouterModule],
    template: `
    <div class="min-h-screen bg-gradient-to-b from-white via-pink-50/30 to-pink-100/20 py-16">
      <div class="max-w-3xl mx-auto px-4 sm:px-6">
        <!-- Page Title -->
        <div class="text-center mb-12">
          <h1 class="text-3xl sm:text-4xl font-bold text-gray-900 mb-4 relative inline-block">
            About Perla
            <span class="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full"></span>
          </h1>
        </div>

        <!-- Content -->
        <div class="bg-white rounded-2xl shadow-md p-8 mb-12">
          <div class="prose prose-pink max-w-none">
            <div class="flex justify-center mb-8">
              <img src="assets/images/about.jpg" alt="Perla Accessories" class="rounded-2xl shadow-lg w-full max-w-md object-cover h-64" onerror="this.src='assets/images/placeholder.jpg'; this.onerror='';" />
            </div>
            
            <p class="mb-6 text-gray-600 text-lg font-medium">We're Perla, a brand that's been shining for three years. We're all about bringing you unique, standout pieces you won't find anywhere else.</p>
            
            <p class="mb-6 text-gray-600">Every accessory you pick should feel like it was made just for you, because we believe in the magic of one of a kind style. That's why we focus on limited edition pieces, so you can always rock something different 🌸🎀🩷</p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-8 mb-4">Our Mission</h2>
            <p class="text-gray-600">To create beautiful, high-quality accessories that help you express your unique personality and style while offering exceptional customer service.</p>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-8 mb-4">Our Values</h2>
            <ul class="list-disc pl-6 text-gray-600 space-y-2">
              <li>Quality craftsmanship in every piece</li>
              <li>Uniqueness that sets you apart</li>
              <li>Customer satisfaction is our top priority</li>
              <li>Affordability without compromising quality</li>
            </ul>
            
            <h2 class="text-xl font-semibold text-gray-800 mt-8 mb-4">Follow Us</h2>
            <p class="text-gray-600">Stay connected with us on social media for the latest releases, styling tips, and special offers.</p>
            
            <div class="flex space-x-5 mt-4">
              <a href="https://www.instagram.com/perlaaccessoriesboutique?igsh=MXBzYmU2YmRvZXc5cw==" target="_blank" rel="noopener" class="text-gray-600 hover:text-pink-500 transition transform hover:scale-110">
                <div class="p-3 rounded-full hover:bg-pink-50 transition-all duration-300 shadow-sm hover:shadow-md hover:shadow-pink-200/50">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.2c3.2 0 3.584.012 4.85.07 3.24.148 4.771 1.671 4.919 4.919.058 1.267.069 1.645.069 4.849s-.012 3.582-.069 4.849c-.149 3.245-1.679 4.771-4.919 4.919-1.265.058-1.644.07-4.85.07s-3.584-.012-4.849-.07c-3.245-.148-4.771-1.674-4.919-4.919-.058-1.267-.07-1.645-.07-4.849s.013-3.582.07-4.849c.148-3.245 1.674-4.771 4.919-4.919 1.267-.058 1.645-.07 4.849-.07zM12 0c-3.259 0-3.667.013-4.947.072-4.354.2-6.782 2.618-6.98 6.979C0 8.333 0 8.742 0 12c0 3.259.013 3.668.072 4.948.2 4.354 2.618 6.782 6.979 6.98 1.28.059 1.689.072 4.949.072 3.259 0 3.668-.013 4.948-.072 4.354-.198 6.782-2.626 6.98-6.98.058-1.28.072-1.689.072-4.948 0-3.258-.014-3.667-.072-4.947-.198-4.362-2.626-6.78-6.98-6.98C15.667.013 15.259 0 12 0zm0 5.8a6.2 6.2 0 1 0 0 12.4A6.2 6.2 0 0 0 12 5.8zm0 10.2a4 4 0 1 1 0-8.001 4 4 0 0 1 0 8zm6.4-11.845a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z"/>
                  </svg>
                </div>
              </a>
              <a href="https://www.tiktok.com/@perlaaccesories0?_t=ZS-8vtSpUwLtoO&_r=1" target="_blank" rel="noopener" class="text-gray-600 hover:text-pink-500 transition transform hover:scale-110">
                <div class="p-3 rounded-full hover:bg-pink-50 transition-all duration-300 shadow-sm hover:shadow-md hover:shadow-pink-200/50">
                  <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.298-.002.595.042.88.13V9.4a6.37 6.37 0 0 0-1-.08A6.34 6.34 0 0 0 3 15.66a6.34 6.34 0 0 0 10.95 4.37l.02.01v-9.1a8.32 8.32 0 0 0 5.62 2.19V9.68a4.85 4.85 0 0 1-2.83-.99"/>
                  </svg>
                </div>
              </a>
            </div>
          </div>
        </div>
        
        <!-- Back Button -->
        <div class="text-center">
          <a routerLink="/" class="inline-flex items-center text-pink-600 hover:text-pink-700 font-medium">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Home
          </a>
        </div>
      </div>
    </div>
  `,
})
export class AboutComponent { } 