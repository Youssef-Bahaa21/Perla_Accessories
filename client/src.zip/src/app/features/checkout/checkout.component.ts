import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { CartItem, CartService } from '../../core/services/cart/cart.service';
import { ApiService } from '../../core/services/api/api.service';
import { ShippingInfo, Order } from '../../core/models';
import { ShippingDetailsComponent, CheckoutService } from '../shiiping-details/shiiping-details.component';
import { AuthService } from '../../core/services/auth/auth.service';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './checkout.component.html',
})
export class CheckoutComponent implements OnInit {
  cartItems: CartItem[] = [];
  shippingInfo?: ShippingInfo;
  total = 0;
  deliveryFee = 0;
  couponCode = '';
  discount = 0;
  couponError = '';
  couponApplied = '';
  couponLocked = false;
  loading = false;
  error = '';

  private api = inject(ApiService);
  private cart = inject(CartService);
  private router = inject(Router);
  private auth = inject(AuthService);
  private checkoutService = inject(CheckoutService);

  ngOnInit() {
    /* Check for stored shipping info */
    const savedShippingInfo = this.checkoutService.getShippingInfo();
    if (savedShippingInfo) {
      this.shippingInfo = savedShippingInfo;
    } else {
      /* If no shipping info is found, redirect back to the shipping page */
      this.router.navigateByUrl('/shipping');
      return;
    }

    /* shipping fee */
    this.api.settings.getShippingFee().subscribe({
      next: res => (this.deliveryFee = res.shipping_fee),
      error: () => (this.deliveryFee = 0),
    });

    /* cart totals */
    this.cart.cart$.subscribe(items => {
      this.cartItems = items;

      /* If cart is empty, redirect to cart page */
      if (items.length === 0) {
        this.router.navigateByUrl('/cart');
        return;
      }

      this.total = items.reduce(
        (sum, i) => sum + i.product.price * i.qty,
        0,
      );
    });
  }

  getUserId(): number | null {
    return this.auth.currentUser$.value?.id ?? null;
  }

  get grandTotal(): number {
    return this.total + this.deliveryFee - this.discount;
  }

  applyCoupon() {
    this.couponError = '';
    this.couponApplied = '';
    this.couponLocked = false;

    const user = this.auth.currentUser$.value;
    if (!user) {
      this.couponError = 'You must be logged in to use a coupon.';
      return;
    }

    if (!this.couponCode.trim()) {
      this.couponError = 'Please enter a code.';
      return;
    }

    const cartTotal = this.total;
    const email = this.shippingInfo?.email || null;

    this.api.coupons
      .validate(
        this.couponCode.trim(),
        user.id,           // ← from AuthService
        cartTotal,
        email,
      )
      .subscribe({
        next: res => {
          this.discount = res.discount;
          this.couponApplied = `Coupon "${res.code}" applied! You saved EGP ${res.discount}.`;
          this.couponLocked = true;
        },
        error: err => {
          this.discount = 0;
          this.couponError =
            err?.error?.error || 'Invalid or expired coupon.';
          this.couponLocked = true;
        },
      });
  }

  onShipping(info: ShippingInfo) {
    this.shippingInfo = info;
    /* Store shipping info in our service */
    this.checkoutService.saveShippingInfo(info);
  }

  placeOrder() {
    this.error = '';

    if (!this.shippingInfo || this.cartItems.length === 0) {
      this.error = 'Please fill in shipping details and add items to cart.';
      return;
    }

    const { name, address, city, phone, email } = this.shippingInfo;
    if (!name || !address || !city || !phone) {
      this.error = 'Please complete all required shipping fields.';
      return;
    }

    this.loading = true;
    const user = this.auth.currentUser$.value;

    const dto = {
      user_id: user?.id ?? null,
      items: this.cartItems.map(i => ({
        product_id: i.product.id,
        quantity: i.qty,
        unit_price: i.product.price,
      })),
      shipping_name: name,
      shipping_email: email,
      shipping_address: address,
      shipping_city: city,
      shipping_phone: phone,
      delivery_fee: this.deliveryFee,
      coupon_code: this.couponCode.trim() || undefined,
    };

    this.api.orders.create(dto).subscribe({
      next: (order: Order) => {
        setTimeout(() => {
          this.cart.clear();
          /* Clear shipping info after successful order */
          this.checkoutService.clearShippingInfo();
          this.router.navigateByUrl(`/order-confirmation/${order.id}`);
        }, 300);
      },
      error: err => {
        this.error =
          err?.error?.error || 'Could not place order.';
        this.loading = false;
      },
    });
  }
}
