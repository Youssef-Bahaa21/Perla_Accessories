// src/app/features/orders/order-confirmation.component.ts
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ApiService } from '../../core/services/api/api.service';
import { Order } from '../../core/models';

@Component({
  selector: 'app-order-confirmation',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './order-confirmation.component.html',
})
export class OrderConfirmationComponent implements OnInit {
  order: Order | null = null;
  deliveryFee: number = 0;
  loading = true;
  error = '';

  private api = inject(ApiService);
  private route = inject(ActivatedRoute);

  ngOnInit() {
    const param = this.route.snapshot.paramMap.get('id');
    const id = Number(param);

    if (isNaN(id)) {
      this.error = 'Invalid order ID.';
      this.loading = false;
      return;
    }

    this.api.orders.get(id).subscribe({
      next: o => {
        this.order = o;
        this.deliveryFee = Number(o.delivery_fee) || 0;
        this.loading = false;
        if (!o.items || o.items.length === 0) {
          this.error = 'Order items could not be loaded.';
        }
      },
      error: () => {
        this.error = 'Could not load order details.';
        this.loading = false;
      },
    });
  }

  get discountAmount(): number {
    if (!this.order || !this.order.items || this.order.items.length === 0) return 0;

    const subtotal = this.order.items.reduce(
      (sum, i) => sum + (i.unit_price * i.quantity),
      0
    );

    // Discount = subtotal - actual paid (excluding delivery)
    const discount = subtotal - this.order.total;

    return Number((discount > 0 ? discount : 0).toFixed(2));
  }


  get grandTotal(): number {
    if (!this.order || !this.order.items || this.order.items.length === 0) return 0;

    const subtotal = this.order.items.reduce(
      (sum, i) => sum + (i.unit_price * i.quantity),
      0
    );
    let total = subtotal;
    const delivery = Number(this.order.delivery_fee) || 0;

    if (this.order.coupon_code && this.discountAmount > 0) {
      total = subtotal - this.discountAmount;
    }

    return Number((total + delivery).toFixed(2));
  }
}
