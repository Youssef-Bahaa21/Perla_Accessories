
import { Component, OnInit, ViewChild, ElementRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../../core/services/api/api.service';
import { Order } from '../../../core/models';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss'],
})
export class OrderListComponent implements OnInit {
  orders: Order[] = [];
  loading = true;
  error = '';
  baseUrl = 'http://localhost:3000/uploads/';

  private api = inject(ApiService);
  @ViewChild('pdfContent') pdfContentRef!: ElementRef;

  ngOnInit() {
    this.fetchOrders();
  }

  fetchOrders() {
    this.loading = true;
    this.api.orders.list().subscribe({
      next: res => {
        this.orders = res.map((o: any) => ({
          ...o,
          delivery_fee: Number(o.delivery_fee) || 0,
          total: Number(o.total) || 0,
          items: o.items?.map((i: any) => ({
            ...i,
            unit_price: Number(i.unit_price),
            quantity: Number(i.quantity),
            product_name: i.product_name,
            product_image: i.product_image,
          })) || [],
        }));
        this.loading = false;
      },
      error: () => {
        this.error = '❌ Failed to load orders.';
        this.loading = false;
      },
    });
  }

  updateStatus(orderId: number, status: string) {
    this.api.orders.update(orderId, { status }).subscribe({
      next: () => {
        const order = this.orders.find(o => o.id === orderId);
        if (order) order.status = status;
      },
      error: () => alert('❌ Failed to update status'),
    });
  }

  archiveOrder(orderId: number) {
    if (!confirm('Archive this order?')) return;
    this.api.orders.delete(orderId).subscribe({
      next: () => this.orders = this.orders.filter(o => o.id !== orderId),
      error: () => alert('❌ Failed to archive'),
    });
  }

  getStatusClasses(status: string): string {
    const classes: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-700',
      paid: 'bg-blue-100 text-blue-700',
      shipped: 'bg-gray-100 text-gray-700',
      completed: 'bg-green-100 text-green-700',
      cancelled: 'bg-red-100 text-red-700',
    };
    return classes[status] || 'bg-gray-100 text-gray-700';
  }

  getDeliveryFee(order: Order): number {
    return Number(order.delivery_fee) || 0;
  }

  getSubtotalBeforeDiscount(order: Order): number {
    return order.items?.reduce((sum, i) => sum + Number(i.unit_price) * i.quantity, 0) || 0;
  }

  getDiscount(order: Order): number {
    const subtotal = this.getSubtotalBeforeDiscount(order);
    return Math.max(0, subtotal - (order.total || 0));
  }

  getGrandTotal(order: Order): number {
    return (order.total || 0) + this.getDeliveryFee(order);
  }

  downloadInvoice(order: Order) {
    const itemsHtml = order.items?.map(i => `
      <tr>
        <td style="padding: 8px; display: flex; align-items: center; gap: 10px;">
          ${i.product_image
        ? `<img src="${this.baseUrl + i.product_image}" 
                     style="width:40px; height:40px; object-fit:cover; border-radius:5px;" crossOrigin="anonymous" />`
        : ''}
          <div>
            <div><strong>${i.product_name || 'Product #' + i.product_id}</strong></div>
            <div style="font-size: 11px; color: #888;">#${i.product_id}</div>
          </div>
        </td>
        <td style="text-align:center;">${i.quantity}</td>
        <td style="text-align:right;">EGP ${Number(i.unit_price).toFixed(2)}</td>
        <td style="text-align:right;">EGP ${(Number(i.unit_price) * i.quantity).toFixed(2)}</td>
      </tr>
    `).join('') || '';

    const discount = this.getDiscount(order);
    const html = `
      <div style="font-family: Arial; padding: 20px; width: 800px;">
        <h2 style="color:#e91e63">Invoice #${order.id}</h2>
        <p><strong>Date:</strong> ${new Date(order.created_at).toLocaleString()}</p>
        <p><strong>User ID:</strong> ${order.user_id}</p>
        <h3>Shipping Details</h3>
        <p><strong>Name:</strong> ${order.shipping_name}</p>
        <p><strong>Address:</strong> ${order.shipping_address}</p>
        <p><strong>City:</strong> ${order.shipping_city}</p>
        <p><strong>Phone:</strong> ${order.shipping_phone}</p>
  
        <h3>Items</h3>
        <table style="width:100%; border-collapse: collapse;">
          <thead>
            <tr>
              <th style="text-align:left;">Product</th>
              <th style="text-align:center;">Qty</th>
              <th style="text-align:right;">Unit Price</th>
              <th style="text-align:right;">Subtotal</th>
            </tr>
          </thead>
          <tbody>${itemsHtml}</tbody>
        </table>
  
        <div style="text-align:right; margin-top:20px;">
          <p><strong>Subtotal:</strong> EGP ${this.getSubtotalBeforeDiscount(order).toFixed(2)}</p>
          ${order.coupon_code && discount > 0
        ? `<p><strong>Discount:</strong> -EGP ${discount.toFixed(2)}</p>` : ''}
          <p><strong>Delivery Fee:</strong> EGP ${order.delivery_fee.toFixed(2)}</p>
          <p style="font-weight:bold; color:#e91e63"><strong>Grand Total:</strong> EGP ${this.getGrandTotal(order).toFixed(2)}</p>
        </div>
      </div>
    `;

    const container = this.pdfContentRef.nativeElement as HTMLElement;
    container.innerHTML = html;

    html2canvas(container, {
      useCORS: true,
      allowTaint: false,
      logging: true,
    }).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'pt', 'a4');
      const width = 595.28;
      const height = canvas.height * width / canvas.width;
      pdf.addImage(imgData, 'PNG', 0, 0, width, height);
      pdf.save(`Invoice-${order.id}.pdf`);
    });
  }

}
