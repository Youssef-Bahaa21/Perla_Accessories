import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../../../core/services/api/api.service';

@Component({
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  selector: 'app-admin-settings',
  templateUrl: './settings.component.html',
})
export class SettingsComponent implements OnInit {
  private fb = inject(FormBuilder);
  private api = inject(ApiService);

  form = this.fb.group({
    shipping_fee: [0, [Validators.required, Validators.min(0)]],
  });

  loading = false;
  success = '';
  error = '';

  ngOnInit() {
    this.loading = true;
    this.api.settings.getShippingFee().subscribe({
      next: resp => {
        this.form.patchValue({ shipping_fee: resp.shipping_fee });
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load current shipping fee.';
        this.loading = false;
      }
    });
  }

  save() {
    if (this.form.invalid) return;
    this.loading = true;
    this.success = this.error = '';
    const fee = this.form.value.shipping_fee!;
    this.api.settings.updateShippingFee(fee).subscribe({
      next: () => {
        this.success = 'Shipping fee updated successfully!';
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to update shipping fee.';
        this.loading = false;
      }
    });
  }
}
