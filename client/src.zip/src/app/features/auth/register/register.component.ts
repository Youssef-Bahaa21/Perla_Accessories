import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
  AbstractControl,
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthService, User } from '../../../core/services/auth/auth.service';


@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './register.component.html',
})
export class RegisterComponent {
  form: FormGroup;
  error = '';

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
  ) {
    this.form = this.fb.group(
      {
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]],
        confirm: ['', Validators.required],
      },
      { validators: this.passwordsMatchValidator },
    );
  }

  private passwordsMatchValidator(ctrl: AbstractControl) {
    const pwd = ctrl.get('password')?.value;
    const cfm = ctrl.get('confirm')?.value;
    return pwd === cfm ? null : { mismatch: true };
  }

  submit() {
    if (this.form.invalid) return;
    const { email, password } = this.form.value;

    this.auth.register(email, password).subscribe({
      next: ({ user }) => {
        const target = user.role === 'admin' ? '/admin' : '/account/orders';
        this.router.navigateByUrl(target);
      },
      error: (err: any) => {
        this.error = err?.error?.message || 'Registration failed';
      },
    });
  }
}
