import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Order } from '../../../core/models';
import { ApiService } from '../../../core/services/api/api.service';
import { AuthService } from '../../../core/services/auth/auth.service';

@Component({
  selector: 'app-orders',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './orders.component.html',
})
export class OrdersComponent implements OnInit {
  orders: Order[] = [];
  loading = true;
  error = '';

  private api = inject(ApiService);
  private auth = inject(AuthService);

  ngOnInit() {
    const user = this.auth.currentUser$.value;

    if (!user) {
      this.error = 'Not authenticated';
      this.loading = false;
      return;
    }

    /* If your back‑end already has /api/orders/my, call that instead
       and remove the filter step below. */
    this.api.orders.list().subscribe({
      next: all => {
        this.orders = all.filter(o => o.user_id === user.id);
        this.loading = false;
      },
      error: () => {
        this.error = 'Could not load your orders.';
        this.loading = false;
      },
    });
  }

  getDeliveryFee(o: Order): number {
    return Number(o.delivery_fee ?? 0);
  }

  getDiscount(o: Order): number {
    const items = o.items ?? [];
    const subtotal = items.reduce(
      (sum, i) => sum + i.unit_price * i.quantity,
      0,
    );
    return Number((subtotal - o.total).toFixed(2));
  }

  getGrandTotal(o: Order): number {
    const total = Number(o.total) || 0;
    const delivery = this.getDeliveryFee(o);
    return Number((total + delivery).toFixed(2));
  }
}
