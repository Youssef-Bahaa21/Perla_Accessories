import { CUSTOM_ELEMENTS_SCHEMA, Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ApiService } from '../../core/services/api/api.service';
import { Product } from '../../core/models';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { ProductService } from '../../core/services/product.service';

@Component({
  selector: 'app-landing-page',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './landing.component.html',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class LandingPageComponent implements OnInit {
  featuredProducts: Product[] = [];
  loading = true;
  error = '';
  fallbackImage = 'https://via.placeholder.com/150';

  private productSvc = inject(ProductService);

  ngOnInit(): void {
    this.productSvc.getProducts<Product>(1, 20).subscribe({
      next: resp => {
        const all: Product[] = resp.data;

        this.featuredProducts = all
          .filter(prod => prod.is_featured === 1)
          .filter(
            prod =>
              Array.isArray((prod as any).images) &&
              (prod as any).images.length > 0,
          )
          .map(prod => {
            const imgs = (prod as any).images.map((img: any) => ({
              id: img.id,
              url: img.url,
            }));
            return {
              ...prod,
              price: +prod.price,
              images: imgs,
            } as Product;
          });

        this.loading = false;
      },
      error: () => {
        this.error = 'Could not load featured products.';
        this.loading = false;
      },
    });
  }

  onImageError(event: Event) {
    (event.target as HTMLImageElement).src = this.fallbackImage;
  }
}