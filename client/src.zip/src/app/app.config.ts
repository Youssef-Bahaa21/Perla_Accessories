import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';

import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgxSpinnerModule } from 'ngx-spinner';
import { provideToastr } from 'ngx-toastr';

import { loadingInterceptor } from './core/interceptor/loading.interceptor';
import { messageInterceptor } from './core/interceptor/message.interceptor';
import { credentialsInterceptor } from './core/interceptor/credentials.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    importProvidersFrom(
      BrowserAnimationsModule,
      NgxSpinnerModule.forRoot({ type: 'ball-scale-multiple' }),
    ),

    // ---- HttpClient with only the interceptors we still need ----
    provideHttpClient(
      withInterceptors([
        credentialsInterceptor,  // <- sends/receives the cookie
        loadingInterceptor,
        messageInterceptor,
      ]),
    ),

    provideRouter(routes),

    provideToastr({
      timeOut: 3000,
      positionClass: 'toast-top-right',
      preventDuplicates: true,
      progressBar: true,
      closeButton: true,
    }),

    provideAnimations(),
  ],
};
