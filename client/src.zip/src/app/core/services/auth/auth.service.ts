import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap, map } from 'rxjs';
import { environment as env } from '../../../../environments/environment';

export interface User {
  id: number;
  email: string;
  role: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  readonly currentUser$ = new BehaviorSubject<User | null>(null);

  constructor(private http: HttpClient) { }

  /* ----------  private helper ---------- */
  private handleAuth(
    req$: Observable<{ user: User }>,
  ): Observable<{ user: User }> {
    return req$.pipe(
      tap(({ user }) => this.currentUser$.next(user)),
    );
  }

  /* ----------  public API ---------- */
  initialise() {
    this.http
      .get<User>(`${env.api}/api/auth/me`)
      .subscribe({
        next: user => this.currentUser$.next(user),
        error: () => this.currentUser$.next(null),
      });
  }

  register(email: string, password: string) {
    return this.handleAuth(
      this.http.post<{ user: User }>(
        `${env.api}/api/auth/register`,
        { email, password },
      ),
    );
  }

  login(email: string, password: string) {
    return this.handleAuth(
      this.http.post<{ user: User }>(
        `${env.api}/api/auth/login`,
        { email, password },
      ),
    );
  }

  logout() {
    return this.http
      .post(`${env.api}/api/auth/logout`, {})
      .pipe(tap(() => this.currentUser$.next(null)));
  }
}
