import { inject } from '@angular/core';
import { CanActivateFn, Router, UrlTree } from '@angular/router';
import { map, take } from 'rxjs';
import { AuthService } from '../../services/auth/auth.service';

/**
 * Allows navigation only when AuthService has a user.
 * If `currentUser$` is null ➜ redirects to /login.
 *
 * Usage in routes:
 *   { path: 'account', canActivate: [authGuard], loadComponent: … }
 */
export const authGuard: CanActivateFn = (): ReturnType<CanActivateFn> => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return auth.currentUser$.pipe(
    take(1),                                     // take first value
    map(user =>
      user ? true : (router.parseUrl('/login') as UrlTree),
    ),
  );
};
