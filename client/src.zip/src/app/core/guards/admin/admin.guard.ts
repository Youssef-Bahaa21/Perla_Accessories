import { inject } from '@angular/core';
import { CanActivateFn, Router, UrlTree } from '@angular/router';
import { AuthService } from '../../services/auth/auth.service';


/**
 * Allows access only when the current user is present AND has role === 'admin'.
 * Otherwise redirects:
 *   – unauthenticated  → /login
 *   – logged‑in non‑admin → /
 */
export const adminGuard: CanActivateFn = (): boolean | UrlTree => {
  const router = inject(Router);
  const auth = inject(AuthService);

  const user = auth.currentUser$.value;

  if (!user) {
    // no cookie or not yet logged‑in
    return router.parseUrl('/login');
  }

  if (user.role === 'admin') {
    return true;
  }

  // logged‑in but not an admin
  return router.parseUrl('/');
};
