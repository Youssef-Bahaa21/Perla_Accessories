// src/app/shared/components/footer/footer.component.ts

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterModule } from '@angular/router';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterLink],
  templateUrl: './footer.component.html',
})
export class FooterComponent {
  /** compute once at class instantiation */
  year = new Date().getFullYear();
}
