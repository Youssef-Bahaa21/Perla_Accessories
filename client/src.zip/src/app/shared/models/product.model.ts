// Add these properties to your Product interface
export interface Product {
  // ... existing properties
  isNew?: boolean;
  isBestSeller?: boolean;
}