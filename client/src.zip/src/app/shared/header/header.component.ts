import { Component, HostListener, inject } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { RouterLink, RouterLinkActive, Router } from '@angular/router';
import { PLATFORM_ID } from '@angular/core';

import { CartService } from '../../core/services/cart/cart.service';
import { AuthService } from '../../core/services/auth/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './header.component.html',
})
export class HeaderComponent {
  isMobileMenuOpen = false;
  cartCount = 0;
  isScrolled = false;

  private platformId = inject(PLATFORM_ID);
  private cart = inject(CartService);
  private router = inject(Router);
  private auth = inject(AuthService);

  constructor() {
    /* update cart icon on every cart change */
    this.cart.cart$.subscribe(() =>
      (this.cartCount = this.cart.getItemCount()),
    );
  }

  /* 🔑 login state – no more localStorage */
  get isLoggedIn(): boolean {
    return !!this.auth.currentUser$.value;
  }

  @HostListener('window:scroll', [])
  onWindowScroll(): void {
    this.isScrolled = window.pageYOffset > 20;
  }

  logout(): void {
    this.auth.logout().subscribe(() => {
      this.cart.clear();             // optional: empty cart on sign‑out
      this.router.navigateByUrl('/');
    });
  }

  toggleMobileMenu(): void {
    this.isMobileMenuOpen = !this.isMobileMenuOpen;
  }
  closeMobileMenu(): void {
    this.isMobileMenuOpen = false;
  }
}
